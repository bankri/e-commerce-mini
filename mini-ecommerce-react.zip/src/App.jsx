import { useState } from 'react';
import { motion } from 'framer-motion';

// Dummy data produk
const products = [
  { id: 1, name: "Sneakers", price: 350000, image: "https://picsum.photos/200?1" },
  { id: 2, name: "T-Shirt", price: 150000, image: "https://picsum.photos/200?2" },
  { id: 3, name: "Backpack", price: 275000, image: "https://picsum.photos/200?3" },
  { id: 4, name: "Headphones", price: 500000, image: "https://picsum.photos/200?4" },
];

export default function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    const existingItem = cart.find((item) => item.id === product.id);
    if (existingItem) {
      setCart(cart.map((item) =>
        item.id === product.id ? { ...item, qty: item.qty + 1 } : item
      ));
    } else {
      setCart([...cart, { ...product, qty: 1 }]);
    }
  };

  const decreaseQty = (id) => {
    setCart(cart.map((item) =>
      item.id === id ? { ...item, qty: item.qty - 1 } : item
    ).filter((item) => item.qty > 0));
  };

  const removeFromCart = (id) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const total = cart.reduce((acc, item) => acc + item.price * item.qty, 0);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-3xl font-bold text-center mb-6">Mini E-Commerce 🛒</h1>
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 grid sm:grid-cols-2 gap-4">
          {products.map((p) => (
            <motion.div
              key={p.id}
              whileHover={{ scale: 1.05 }}
              className="bg-white rounded-2xl shadow-md p-4 flex flex-col items-center"
            >
              <img src={p.image} alt={p.name} className="w-32 h-32 object-cover rounded-xl mb-4" />
              <h2 className="font-semibold text-lg">{p.name}</h2>
              <p className="text-gray-500">Rp {p.price.toLocaleString()}</p>
              <button
                onClick={() => addToCart(p)}
                className="mt-3 px-4 py-2 bg-blue-500 text-white rounded-xl hover:bg-blue-600"
              >
                Add to Cart
              </button>
            </motion.div>
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-md p-4">
          <h2 className="text-xl font-bold mb-4">Keranjang</h2>
          {cart.length === 0 ? (
            <p className="text-gray-500">Keranjang kosong</p>
          ) : (
            <div>
              {cart.map((item) => (
                <div key={item.id} className="flex justify-between items-center border-b py-2">
                  <span>{item.name}</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => decreaseQty(item.id)}
                      className="px-2 bg-gray-200 rounded"
                    >
                      -
                    </button>
                    <span>{item.qty}</span>
                    <button
                      onClick={() => addToCart(item)}
                      className="px-2 bg-gray-200 rounded"
                    >
                      +
                    </button>
                    <span className="text-sm text-gray-600">Rp {(item.price * item.qty).toLocaleString()}</span>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      ✕
                    </button>
                  </div>
                </div>
              ))}
              <div className="mt-4 font-bold text-lg">
                Total: Rp {total.toLocaleString()}
              </div>
              <button className="mt-4 w-full px-4 py-2 bg-green-500 text-white rounded-xl hover:bg-green-600">
                Checkout
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
